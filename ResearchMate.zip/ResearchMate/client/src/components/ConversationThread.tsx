import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ConversationThreadProps } from "@/lib/types";
import TopicRelevance from "./TopicRelevance";

export default function ConversationThread({
  readingLevel,
  paperAnalysis,
  topicRelevance,
  messages,
  isAnalyzing,
  onTopicSubmit,
  onReadingLevelChange,
  onUserQuestion,
}: ConversationThreadProps) {
  const [userInput, setUserInput] = useState("");
  const [showAdditionalOptions, setShowAdditionalOptions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserInput(e.target.value);
  };

  const handleSubmit = () => {
    if (userInput.trim()) {
      onUserQuestion(userInput);
      setUserInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey && userInput.trim()) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const formatReadingLevel = (level: string) => {
    switch (level) {
      case "first-read":
        return "first read";
      case "second-read":
        return "second read";
      case "third-read":
        return "third read";
      case "quick-summary":
        return "quick summary";
      default:
        return level;
    }
  };

  const handleTopicResponse = (topics: string) => {
    onTopicSubmit(topics);
    setShowAdditionalOptions(true);
  };

  // Render each analysis section based on the reading level
  const renderAnalysisContent = () => {
    if (isAnalyzing) {
      return (
        <div className="flex items-center space-x-2">
          <div className="animate-pulse flex space-x-4">
            <div className="flex-1 space-y-4 py-1">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              </div>
            </div>
          </div>
          <span className="text-gray-500">Analyzing paper...</span>
        </div>
      );
    }

    if (!paperAnalysis) {
      return <p className="text-gray-600">Analysis will appear here...</p>;
    }

    // First read or quick summary content
    return (
      <div className="prose prose-sm max-w-none text-gray-700">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Paper Overview</h3>
        
        {/* Key Contributions Section */}
        {paperAnalysis.contributions && paperAnalysis.contributions.length > 0 && (
          <div className="mb-5">
            <h4 className="text-lg font-medium text-gray-900 mb-2">Key Contributions</h4>
            <ul className="list-disc pl-5 space-y-1">
              {paperAnalysis.contributions.map((contribution, index) => (
                <li key={index}>{contribution}</li>
              ))}
            </ul>
          </div>
        )}
        
        {/* Background Section */}
        {paperAnalysis.background && (
          <div className="mb-5">
            <h4 className="text-lg font-medium text-gray-900 mb-2">Background & Context</h4>
            <p>{paperAnalysis.background}</p>
          </div>
        )}

        {/* Paper Structure Section */}
        {paperAnalysis.structure && paperAnalysis.structure.length > 0 && (
          <div className="mb-5">
            <h4 className="text-lg font-medium text-gray-900 mb-2">Paper Structure</h4>
            <div className="space-y-3">
              {paperAnalysis.structure.map((section, index) => (
                <div key={index}>
                  <h5 className="font-medium text-gray-800">{section.title}</h5>
                  <p className="text-sm text-gray-600">{section.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Key Concepts Section */}
        {paperAnalysis.keyConcepts && paperAnalysis.keyConcepts.length > 0 && (
          <div className="mb-5">
            <h4 className="text-lg font-medium text-gray-900 mb-2">Key Concepts</h4>
            <div className="space-y-3">
              {paperAnalysis.keyConcepts.map((concept, index) => (
                <div key={index}>
                  <h5 className="font-medium text-gray-800">{concept.title}</h5>
                  <p className="text-sm text-gray-600">{concept.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Methodology Highlights */}
        {paperAnalysis.methodology && (
          <div className="mb-5">
            <h4 className="text-lg font-medium text-gray-900 mb-2">Methodology Highlights</h4>
            <p>{paperAnalysis.methodology}</p>
          </div>
        )}

        {/* Results Summary */}
        {paperAnalysis.results && (
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-2">Results & Impact</h4>
            <p>{paperAnalysis.results}</p>
          </div>
        )}

        {/* Overview (used for quick summary) */}
        {paperAnalysis.overview && (
          <div>
            <p>{paperAnalysis.overview}</p>
          </div>
        )}
      </div>
    );
  };

  // Render topic relevance section if available
  const renderTopicRelevance = () => {
    if (!topicRelevance) return null;

    return (
      <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 max-w-[calc(100%-3rem)]">
        <h4 className="text-lg font-medium text-gray-900 mb-2">Connections to Your Topics</h4>
        <div className="prose prose-sm max-w-none text-gray-700">
          {topicRelevance.explanation && <p>{topicRelevance.explanation}</p>}
          
          {topicRelevance.connections && topicRelevance.connections.length > 0 && (
            <>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                {topicRelevance.connections.map((connection, index) => (
                  <li key={index}>{connection}</li>
                ))}
              </ul>
            </>
          )}
          
          {topicRelevance.nonRelevantAspects && topicRelevance.nonRelevantAspects.length > 0 && (
            <>
              <p className="mt-3">However, the paper doesn't directly address:</p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                {topicRelevance.nonRelevantAspects.map((aspect, index) => (
                  <li key={index}>{aspect}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>
    );
  };

  // Render additional reading options
  const renderAdditionalOptions = () => {
    if (!showAdditionalOptions && !topicRelevance) return null;

    return (
      <div className="flex">
        <div className="flex-shrink-0 mr-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5 text-primary"
            >
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M12 16v-4"></path>
              <path d="M12 8h.01"></path>
            </svg>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 max-w-[calc(100%-3rem)]">
          <p className="text-gray-800 mb-3">
            Would you like to explore this paper further with a more detailed analysis or from a particular perspective?
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
            <Button
              variant="outline"
              className="border-primary/20 text-primary hover:bg-primary/5 justify-start"
              onClick={() => onReadingLevelChange("second-read")}
              disabled={readingLevel === "second-read"}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-2"
              >
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                <line x1="11" y1="8" x2="11" y2="14"></line>
                <line x1="8" y1="11" x2="14" y2="11"></line>
              </svg>
              Second read - detailed analysis
            </Button>
            <Button
              variant="outline"
              className="border-secondary/20 text-secondary hover:bg-secondary/5 justify-start"
              onClick={() => onReadingLevelChange("third-read")}
              disabled={readingLevel === "third-read"}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-2"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="9" y1="9" x2="15" y2="9"></line>
                <line x1="9" y1="12" x2="15" y2="12"></line>
                <line x1="9" y1="15" x2="15" y2="15"></line>
              </svg>
              Third read - line by line explanation
            </Button>
            <Button
              variant="outline"
              className="border-accent/20 text-accent hover:bg-accent/5 justify-start"
              onClick={() => onUserQuestion("Explain the methodology in this paper in more detail")}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-2"
              >
                <path d="M16.5 9.4l-9-5.19M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                <line x1="12" y1="22.08" x2="12" y2="12"></line>
              </svg>
              Methodology perspective
            </Button>
            <Button
              variant="outline"
              className="border-gray-200 text-gray-700 hover:bg-gray-50 justify-start"
              onClick={() => onUserQuestion("Provide a critical evaluation of this paper's strengths and weaknesses")}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-2"
              >
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
              </svg>
              Critical evaluation perspective
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* AI Welcome Message */}
      <div className="flex">
        <div className="flex-shrink-0 mr-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5 text-primary"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="3" y1="9" x2="21" y2="9"></line>
              <line x1="9" y1="21" x2="9" y2="9"></line>
            </svg>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 max-w-[calc(100%-3rem)]">
          <p className="text-gray-800">
            I'll help you understand this paper with a{" "}
            <span className="font-medium text-primary">
              {formatReadingLevel(readingLevel)}
            </span>{" "}
            analysis. Let me break it down for you.
          </p>
        </div>
      </div>

      {/* AI Analysis */}
      <div className="flex">
        <div className="flex-shrink-0 mr-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5 text-primary"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="3" y1="9" x2="21" y2="9"></line>
              <line x1="9" y1="21" x2="9" y2="9"></line>
            </svg>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-5 border border-gray-200 max-w-[calc(100%-3rem)]">
          {renderAnalysisContent()}
        </div>
      </div>

      {/* Topic Relevance Question */}
      <TopicRelevance 
        onTopicSubmit={handleTopicResponse}
        topicRelevance={topicRelevance}
        isLoading={isAnalyzing}
      />

      {/* Topic Relevance Response (if available) */}
      {topicRelevance && (
        <div className="flex">
          <div className="flex-shrink-0 mr-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-primary"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="3" y1="9" x2="21" y2="9"></line>
                <line x1="9" y1="21" x2="9" y2="9"></line>
              </svg>
            </div>
          </div>
          {renderTopicRelevance()}
        </div>
      )}

      {/* Additional Reading Options */}
      {renderAdditionalOptions()}

      {/* Conversation Messages */}
      {messages.map((message, index) => (
        <div 
          key={index} 
          className={`flex ${message.role === 'user' ? 'justify-end' : ''}`}
        >
          {message.role === 'assistant' && (
            <div className="flex-shrink-0 mr-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-primary"
                >
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                  <line x1="3" y1="9" x2="21" y2="9"></line>
                  <line x1="9" y1="21" x2="9" y2="9"></line>
                </svg>
              </div>
            </div>
          )}
          <div 
            className={`rounded-lg shadow-sm p-4 border ${
              message.role === 'user' 
                ? 'bg-blue-50 border-blue-200 ml-3' 
                : 'bg-white border-gray-200 max-w-[calc(100%-3rem)]'
            }`}
          >
            <p className={message.role === 'user' ? 'text-blue-800' : 'text-gray-800'}>
              {message.content}
            </p>
          </div>
          {message.role === 'user' && (
            <div className="flex-shrink-0 ml-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-blue-600"
                >
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </div>
            </div>
          )}
        </div>
      ))}

      <div ref={messagesEndRef} />

      {/* User Input Section */}
      <div className="sticky bottom-4 mt-6">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-3">
          <div className="flex items-center">
            <Input
              value={userInput}
              onChange={handleInputChange}
              onKeyDown={handleKeyPress}
              placeholder="Ask a question about this paper..."
              className="flex-grow bg-gray-50 border border-gray-200"
              disabled={isAnalyzing}
            />
            <Button
              className="ml-2"
              size="icon"
              onClick={handleSubmit}
              disabled={!userInput.trim() || isAnalyzing}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5"
              >
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
