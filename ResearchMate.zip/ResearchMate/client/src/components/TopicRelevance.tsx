import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TopicRelevanceProps } from "@/lib/types";

export default function TopicRelevance({
  onTopicSubmit,
  topicRelevance,
  isLoading,
}: TopicRelevanceProps) {
  const [showTopicInput, setShowTopicInput] = useState(false);
  const [topic, setTopic] = useState("");

  const handleYesClick = () => {
    setShowTopicInput(true);
  };

  const handleNoClick = () => {
    // Just hide the question and don't show the input
  };

  const handleTopicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTopic(e.target.value);
  };

  const handleSubmit = () => {
    if (topic.trim()) {
      onTopicSubmit(topic);
      setTopic("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && topic.trim()) {
      handleSubmit();
    }
  };

  // If we already have topic relevance results, don't show the initial question
  if (topicRelevance) {
    return null;
  }

  return (
    <div className="space-y-4">
      {!showTopicInput ? (
        <div className="flex">
          <div className="flex-shrink-0 mr-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-primary"
              >
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M12 16v-4"></path>
                <path d="M12 8h.01"></path>
              </svg>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 max-w-[calc(100%-3rem)]">
            <p className="text-gray-800 mb-3">Are you trying to link this paper with any specific topics you're researching?</p>
            <div className="flex flex-wrap gap-2 mt-4">
              <Button
                variant="outline"
                className="bg-primary/5 text-primary hover:bg-primary/10"
                onClick={handleYesClick}
              >
                Yes, I'd like to explore connections
              </Button>
              <Button
                variant="outline"
                className="bg-gray-100 text-gray-700 hover:bg-gray-200"
                onClick={handleNoClick}
              >
                No, continue with analysis
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex">
          <div className="flex-shrink-0 mr-3">
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-blue-600"
              >
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 max-w-[calc(100%-3rem)] w-full">
            <p className="text-gray-700 mb-3">I'm interested in how this relates to:</p>
            <div className="mb-3">
              <Input
                value={topic}
                onChange={handleTopicChange}
                onKeyDown={handleKeyPress}
                placeholder="Enter your research topics..."
                className="w-full"
                disabled={isLoading}
              />
            </div>
            <Button
              onClick={handleSubmit}
              disabled={!topic.trim() || isLoading}
              className="px-4 py-2"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Analyzing...
                </>
              ) : (
                "Submit"
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
