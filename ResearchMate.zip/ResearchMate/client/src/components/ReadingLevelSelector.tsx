import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ReadingLevelSelectorProps } from "@/lib/types";
import { ReadingLevel } from "@shared/schema";

export default function ReadingLevelSelector({
  onLevelSelected,
  paperDetails,
}: ReadingLevelSelectorProps) {
  const [selectedLevel, setSelectedLevel] = useState<ReadingLevel | null>(null);

  const handleLevelSelect = (level: ReadingLevel) => {
    setSelectedLevel(level);
    onLevelSelected(level);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-4 bg-white rounded-lg shadow-sm p-4 border border-gray-200">
        <div className="flex items-start">
          <div className="flex-shrink-0 mr-3">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5 text-primary"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <path d="M9 15v-4"></path>
              <path d="M12 15v-6"></path>
              <path d="M15 15v-2"></path>
            </svg>
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900">
              {paperDetails.title || "Uploaded Paper"}
            </h3>
            <p className="text-sm text-gray-600">
              PDF {paperDetails.pageCount ? `• ${paperDetails.pageCount} pages` : ""}
            </p>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <p className="text-lg text-gray-700 mb-2">
          Is this your first time reading this paper, or would you like a different level of analysis?
        </p>
        <p className="text-gray-600">Choose the option that best suits your needs:</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {/* First Read Option */}
        <Card 
          className={`border border-gray-200 p-6 hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer ${
            selectedLevel === "first-read" ? "ring-2 ring-primary" : ""
          }`}
          onClick={() => handleLevelSelect("first-read")}
        >
          <CardContent className="p-0 space-y-4">
            <div className="flex justify-between items-start">
              <div className="p-3 bg-primary/10 rounded-full text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </svg>
              </div>
              <span className="text-sm font-medium text-gray-500">Recommended</span>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">First Read</h3>
              <p className="text-gray-600 text-sm">
                A detailed yet concise overview highlighting key contributions, background, and important sections. Perfect for your initial exploration.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Second Read Option */}
        <Card 
          className={`border border-gray-200 p-6 hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer ${
            selectedLevel === "second-read" ? "ring-2 ring-primary" : ""
          }`}
          onClick={() => handleLevelSelect("second-read")}
        >
          <CardContent className="p-0 space-y-4">
            <div className="flex justify-between items-start">
              <div className="p-3 bg-accent/10 rounded-full text-accent">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  <line x1="11" y1="8" x2="11" y2="14"></line>
                  <line x1="8" y1="11" x2="14" y2="11"></line>
                </svg>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Second Read</h3>
              <p className="text-gray-600 text-sm">
                A deeper analysis from your preferred perspective. Examines methodologies, evaluates arguments, and analyzes results in greater detail.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Third Read Option */}
        <Card 
          className={`border border-gray-200 p-6 hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer ${
            selectedLevel === "third-read" ? "ring-2 ring-primary" : ""
          }`}
          onClick={() => handleLevelSelect("third-read")}
        >
          <CardContent className="p-0 space-y-4">
            <div className="flex justify-between items-start">
              <div className="p-3 bg-secondary/10 rounded-full text-secondary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M12 9v3m0 0v3m0-3h3m-3 0H9"/>
                  <path d="M5 7C5 5.89543 5.89543 5 7 5H17C18.1046 5 19 5.89543 19 7V19C19 20.1046 18.1046 21 17 21H7C5.89543 21 5 20.1046 5 19V7Z"/>
                  <path d="M15 3V7"/>
                  <path d="M9 3V7"/>
                </svg>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Third Read</h3>
              <p className="text-gray-600 text-sm">
                A comprehensive line-by-line explanation of the entire paper. Best for deep understanding of complex sections or critical review.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Quick Summary Option */}
        <Card 
          className={`border border-gray-200 p-6 hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer ${
            selectedLevel === "quick-summary" ? "ring-2 ring-primary" : ""
          }`}
          onClick={() => handleLevelSelect("quick-summary")}
        >
          <CardContent className="p-0 space-y-4">
            <div className="flex justify-between items-start">
              <div className="p-3 bg-gray-100 rounded-full text-gray-600">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
                </svg>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Quick Summary</h3>
              <p className="text-gray-600 text-sm">
                A brief overview of the paper's main points and findings. Perfect when you need just the essential information quickly.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
