import { useState } from "react";
import PaperInfo from "./PaperInfo";
import ConversationThread from "./ConversationThread";
import { PaperAnalysisProps } from "@/lib/types";

export default function PaperAnalysis({
  paperDetails,
  readingLevel,
  paperAnalysis,
  topicRelevance,
  messages,
  isAnalyzing,
  onBackClick,
  onTopicSubmit,
  onReadingLevelChange,
  onUserQuestion,
}: PaperAnalysisProps) {
  const [analysisTitle, setAnalysisTitle] = useState("Paper Analysis");

  // Update title based on reading level
  useState(() => {
    switch (readingLevel) {
      case "first-read":
        setAnalysisTitle("First Read Analysis");
        break;
      case "second-read":
        setAnalysisTitle("Detailed Analysis");
        break;
      case "third-read":
        setAnalysisTitle("Line-by-Line Breakdown");
        break;
      case "quick-summary":
        setAnalysisTitle("Quick Summary");
        break;
      default:
        setAnalysisTitle("Paper Analysis");
    }
  });

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <button 
          className="text-gray-500 hover:text-gray-700 mr-2"
          onClick={onBackClick}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5"
          >
            <line x1="19" y1="12" x2="5" y2="12"></line>
            <polyline points="12 19 5 12 12 5"></polyline>
          </svg>
        </button>
        <h2 className="text-2xl font-bold text-gray-900">{analysisTitle}</h2>
      </div>

      {/* Paper Info Card */}
      <PaperInfo paperDetails={paperDetails} />

      {/* Conversation Thread */}
      <ConversationThread
        readingLevel={readingLevel}
        paperAnalysis={paperAnalysis}
        topicRelevance={topicRelevance}
        messages={messages}
        isAnalyzing={isAnalyzing}
        onTopicSubmit={onTopicSubmit}
        onReadingLevelChange={onReadingLevelChange}
        onUserQuestion={onUserQuestion}
      />
    </div>
  );
}
