import { PaperInfoProps } from "@/lib/types";
import { Badge } from "@/components/ui/badge";

export default function PaperInfo({ paperDetails }: PaperInfoProps) {
  // Badge colors for different categories
  const badgeColors: Record<string, string> = {
    "Deep Learning": "bg-blue-100 text-blue-800",
    "NLP": "bg-purple-100 text-purple-800",
    "Transformers": "bg-green-100 text-green-800",
    "Computer Vision": "bg-orange-100 text-orange-800",
    "Reinforcement Learning": "bg-red-100 text-red-800",
    "Machine Learning": "bg-indigo-100 text-indigo-800",
    "AI": "bg-cyan-100 text-cyan-800",
  };

  const getDefaultBadgeColor = (index: number) => {
    const colors = [
      "bg-blue-100 text-blue-800",
      "bg-purple-100 text-purple-800",
      "bg-green-100 text-green-800",
      "bg-orange-100 text-orange-800",
      "bg-red-100 text-red-800",
    ];
    return colors[index % colors.length];
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-5 border border-gray-200 mb-6">
      <div className="flex flex-col md:flex-row md:items-start">
        <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-5">
          <div className="w-full md:w-24 h-32 bg-gray-100 rounded border border-gray-200 flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-400 h-10 w-10"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <path d="M9 15v-4"></path>
              <path d="M12 15v-6"></path>
              <path d="M15 15v-2"></path>
            </svg>
          </div>
        </div>
        <div className="flex-grow">
          <h3 className="text-xl font-semibold text-gray-900">
            {paperDetails.title || "Untitled Paper"}
          </h3>
          <div className="mt-1 text-sm text-gray-600">
            {paperDetails.authors || "Unknown Authors"}
          </div>
          <div className="mt-2 text-sm text-gray-600">
            {paperDetails.publication || "Unknown Publication"}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {paperDetails.categories && paperDetails.categories.length > 0 ? (
              paperDetails.categories.map((category, index) => (
                <Badge 
                  key={index} 
                  variant="outline"
                  className={badgeColors[category] || getDefaultBadgeColor(index)}
                >
                  {category}
                </Badge>
              ))
            ) : (
              <Badge variant="outline" className="bg-gray-100 text-gray-800">
                Uncategorized
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
