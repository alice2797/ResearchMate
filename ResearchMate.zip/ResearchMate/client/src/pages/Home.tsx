import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import Layout from "@/components/Layout";
import FileUpload from "@/components/FileUpload";
import ReadingLevelSelector from "@/components/ReadingLevelSelector";
import PaperAnalysisComponent from "@/components/PaperAnalysis";
import { useToast } from "@/hooks/use-toast";
import { uploadPaper, analyzePaper, getTopicRelevance, sendUserQuestion, changeReadingLevel } from "@/lib/api";
import { AppView, Message } from "@/lib/types";
import { ReadingLevel, PaperDetails } from "@shared/schema";
import type { PaperAnalysis as PaperAnalysisType, TopicRelevance } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  
  // Application state
  const [view, setView] = useState<AppView>("initial");
  const [isLoading, setIsLoading] = useState(false);
  const [paperId, setPaperId] = useState<number | null>(null);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [paperDetails, setPaperDetails] = useState<PaperDetails>({});
  const [readingLevel, setReadingLevel] = useState<ReadingLevel>("first-read");
  const [paperAnalysis, setPaperAnalysis] = useState<PaperAnalysisType | null>(null);
  const [topicRelevance, setTopicRelevance] = useState<TopicRelevance | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  // Handle file upload
  const handleFileUpload = async (file: File) => {
    try {
      setIsLoading(true);
      const response = await uploadPaper(file);
      
      if (response.success) {
        setPaperId(response.paperId);
        setPaperDetails(response.paperDetails);
        setView("reading-level");
        
        toast({
          title: "Paper uploaded successfully",
          description: "Now select your preferred reading level.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Could not upload the file",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle reading level selection
  const handleReadingLevelSelect = async (level: ReadingLevel) => {
    if (!paperId) return;
    
    try {
      setIsLoading(true);
      setReadingLevel(level);
      setView("analysis");
      
      const response = await analyzePaper(paperId, level);
      
      if (response.success) {
        setSessionId(response.sessionId);
        setPaperAnalysis(response.analysis);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Analysis failed",
        description: error instanceof Error ? error.message : "Could not analyze the paper",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle topic relevance analysis
  const handleTopicSubmit = async (topics: string) => {
    if (!sessionId) return;
    
    try {
      setIsLoading(true);
      
      // Add user message to conversation
      const userMessage: Message = {
        id: uuidv4(),
        role: "user",
        content: `I'm interested in how this relates to: ${topics}`,
      };
      setMessages((prev) => [...prev, userMessage]);
      
      const response = await getTopicRelevance(sessionId, topics);
      
      if (response.success) {
        setTopicRelevance(response.relevance);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Topic analysis failed",
        description: error instanceof Error ? error.message : "Could not analyze topic relevance",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle user questions
  const handleUserQuestion = async (question: string) => {
    if (!sessionId) return;
    
    try {
      // Add user message to conversation
      const userMessage: Message = {
        id: uuidv4(),
        role: "user",
        content: question,
      };
      setMessages((prev) => [...prev, userMessage]);
      
      setIsLoading(true);
      const response = await sendUserQuestion(sessionId, question);
      
      if (response.success) {
        // Add AI response to conversation
        setMessages((prev) => [...prev, response.message]);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Question failed",
        description: error instanceof Error ? error.message : "Could not process your question",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle changing reading level
  const handleReadingLevelChange = async (level: ReadingLevel) => {
    if (!sessionId || level === readingLevel) return;
    
    try {
      setIsLoading(true);
      setReadingLevel(level);
      
      // Add system message about changing reading level
      const systemMessage: Message = {
        id: uuidv4(),
        role: "assistant",
        content: `Changing to ${level.replace('-', ' ')} analysis...`,
      };
      setMessages((prev) => [...prev, systemMessage]);
      
      const response = await changeReadingLevel(sessionId, level);
      
      if (response.success) {
        setPaperAnalysis(response.analysis);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Reading level change failed",
        description: error instanceof Error ? error.message : "Could not change reading level",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle back button
  const handleBack = () => {
    if (view === "analysis") {
      setView("reading-level");
    } else if (view === "reading-level") {
      setView("initial");
      setPaperId(null);
      setSessionId(null);
      setPaperDetails({});
      setPaperAnalysis(null);
      setTopicRelevance(null);
      setMessages([]);
    }
  };

  return (
    <Layout>
      {view === "initial" && (
        <FileUpload onFileSelected={handleFileUpload} isUploading={isLoading} />
      )}
      
      {view === "reading-level" && (
        <ReadingLevelSelector 
          onLevelSelected={handleReadingLevelSelect} 
          paperDetails={paperDetails} 
        />
      )}
      
      {view === "analysis" && (
        <PaperAnalysisComponent 
          paperDetails={paperDetails}
          readingLevel={readingLevel}
          paperAnalysis={paperAnalysis}
          topicRelevance={topicRelevance}
          messages={messages}
          isAnalyzing={isLoading}
          onBackClick={handleBack}
          onTopicSubmit={handleTopicSubmit}
          onReadingLevelChange={handleReadingLevelChange}
          onUserQuestion={handleUserQuestion}
        />
      )}
    </Layout>
  );
}
