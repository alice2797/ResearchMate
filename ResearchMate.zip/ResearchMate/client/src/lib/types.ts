import { ReadingLevel, PaperDetails } from "@shared/schema";
import type { PaperAnalysis as PaperAnalysisType, TopicRelevance } from "@shared/schema";

export interface FileUploadProps {
  onFileSelected: (file: File) => void;
  isUploading: boolean;
}

export interface ReadingLevelSelectorProps {
  onLevelSelected: (level: ReadingLevel) => void;
  paperDetails: PaperDetails;
}

export interface PaperInfoProps {
  paperDetails: PaperDetails;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export interface ConversationThreadProps {
  readingLevel: ReadingLevel;
  paperAnalysis: PaperAnalysisType | null;
  topicRelevance: TopicRelevance | null;
  messages: Message[];
  isAnalyzing: boolean;
  onTopicSubmit: (topics: string) => void;
  onReadingLevelChange: (level: ReadingLevel) => void;
  onUserQuestion: (question: string) => void;
}

export interface TopicRelevanceProps {
  onTopicSubmit: (topics: string) => void;
  topicRelevance: TopicRelevance | null;
  isLoading: boolean;
}

export interface PaperAnalysisProps {
  paperDetails: PaperDetails;
  readingLevel: ReadingLevel;
  paperAnalysis: PaperAnalysisType | null;
  topicRelevance: TopicRelevance | null;
  messages: Message[];
  isAnalyzing: boolean;
  onBackClick: () => void;
  onTopicSubmit: (topics: string) => void;
  onReadingLevelChange: (level: ReadingLevel) => void;
  onUserQuestion: (question: string) => void;
}

export interface UploadResponse {
  success: boolean;
  paperId: number;
  paperDetails: PaperDetails;
}

export interface AnalysisResponse {
  success: boolean;
  sessionId: number;
  analysis: PaperAnalysisType;
}

export interface TopicRelevanceResponse {
  success: boolean;
  relevance: TopicRelevance;
}

export interface MessageResponse {
  success: boolean;
  message: {
    id: string;
    content: string;
    role: 'assistant';
  };
}

export type AppView = 'initial' | 'reading-level' | 'analysis';
