import { apiRequest } from "./queryClient";
import type { ReadingLevel } from "@shared/schema";
import type { 
  UploadResponse, 
  AnalysisResponse, 
  TopicRelevanceResponse,
  MessageResponse
} from "./types";

export async function uploadPaper(file: File): Promise<UploadResponse> {
  const formData = new FormData();
  formData.append('paper', file);
  
  const response = await fetch('/api/papers/upload', {
    method: 'POST',
    body: formData,
    credentials: 'include',
  });
  
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Failed to upload paper: ${text}`);
  }
  
  return await response.json();
}

export async function analyzePaper(paperId: number, readingLevel: ReadingLevel): Promise<AnalysisResponse> {
  const response = await apiRequest('POST', `/api/papers/${paperId}/analyze`, {
    readingLevel,
  });
  
  return await response.json();
}

export async function getTopicRelevance(sessionId: number, topics: string): Promise<TopicRelevanceResponse> {
  const response = await apiRequest('POST', `/api/sessions/${sessionId}/topic-relevance`, {
    topics,
  });
  
  return await response.json();
}

export async function sendUserQuestion(sessionId: number, question: string): Promise<MessageResponse> {
  const response = await apiRequest('POST', `/api/sessions/${sessionId}/messages`, {
    content: question,
  });
  
  return await response.json();
}

export async function changeReadingLevel(sessionId: number, readingLevel: ReadingLevel): Promise<AnalysisResponse> {
  const response = await apiRequest('POST', `/api/sessions/${sessionId}/reading-level`, {
    readingLevel,
  });
  
  return await response.json();
}
