import pdf from 'pdf-parse';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Function to extract text from a PDF Buffer
export async function extractTextFromPdfBuffer(pdfBuffer: Buffer): Promise<string> {
  try {
    const data = await pdf(pdfBuffer);
    return data.text;
  } catch (error) {
    console.error('Error parsing PDF:', error);
    throw new Error('Failed to parse PDF content');
  }
}

// Function to extract text from a PDF file and clean it up
export async function extractTextFromPdf(file: Express.Multer.File): Promise<string> {
  try {
    const pdfBuffer = file.buffer;
    let text = await extractTextFromPdfBuffer(pdfBuffer);
    
    // Basic text cleanup
    text = text
      .replace(/\r\n/g, '\n')     // Normalize line endings
      .replace(/\n{3,}/g, '\n\n') // Remove excessive line breaks
      .trim();                    // Trim whitespace
    
    return text;
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    throw new Error('Failed to extract text from PDF');
  }
}

// Function to save uploaded file temporarily
export async function saveTempFile(file: Express.Multer.File): Promise<string> {
  try {
    const tempDir = os.tmpdir();
    const filename = `${Date.now()}-${file.originalname}`;
    const filepath = path.join(tempDir, filename);
    
    await fs.promises.writeFile(filepath, file.buffer);
    
    return filepath;
  } catch (error) {
    console.error('Error saving temp file:', error);
    throw new Error('Failed to save temporary file');
  }
}

// Function to cleanup temporary file
export async function removeTempFile(filepath: string): Promise<void> {
  try {
    await fs.promises.unlink(filepath);
  } catch (error) {
    console.error('Error removing temp file:', error);
  }
}

// Function to count pages in a PDF
export async function countPdfPages(pdfBuffer: Buffer): Promise<number> {
  try {
    const data = await pdf(pdfBuffer);
    return data.numpages;
  } catch (error) {
    console.error('Error counting PDF pages:', error);
    return 0;
  }
}
