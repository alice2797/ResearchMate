import OpenAI from "openai";
import { PaperDetails, PaperAnalysis, TopicRelevance, ReadingLevel } from "../shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Initialize OpenAI client only if API key is available
let openai: OpenAI;
try {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
} catch (error) {
  console.warn("OpenAI API key missing. Using fallback mode for demonstration purposes.");
}

// Extract metadata from paper text
export async function extractPaperDetails(paperText: string): Promise<PaperDetails> {
  try {
    if (!openai) {
      console.warn("OpenAI API not available. Using demo paper details.");
      const title = paperText.substring(0, 100).split('\n')[0].trim();
      return {
        title: title || "Sample Research Paper",
        authors: "Author information will appear when API key is provided",
        publication: "Publication details will appear when API key is provided",
        abstract: "To see actual paper analysis, please provide an OpenAI API key",
        categories: ["AI", "Research"]
      };
    }
    
    const prompt = `
      Extract the following information from this research paper:
      - Title
      - Authors (comma separated)
      - Publication venue and date
      - Abstract summary
      - Keywords or research areas (as categories)

      Format the response as a JSON object with the following structure:
      {
        "title": "Paper title",
        "authors": "Author names, comma separated",
        "publication": "Publication venue and date",
        "abstract": "Brief abstract summary",
        "categories": ["category1", "category2", ...]
      }

      Here's the beginning of the paper:
      ${paperText.substring(0, 4000)}
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    return JSON.parse(content);
  } catch (error) {
    console.error("Error extracting paper details:", error);
    return {};
  }
}

// Analyze paper based on reading level
export async function analyzePaper(paperText: string, readingLevel: ReadingLevel): Promise<PaperAnalysis> {
  try {
    if (!openai) {
      console.warn("OpenAI API not available. Using demo paper analysis.");
      return {
        contributions: [
          "This is a demo contribution - please provide an OpenAI API key to see real analysis", 
          "The actual analysis will appear when an API key is provided"
        ],
        background: "This is placeholder content. To see actual paper analysis, please provide an OpenAI API key.",
        structure: [
          { title: "Introduction", description: "Introduces the research problem and context." },
          { title: "Methodology", description: "Describes the approach used in the research." },
          { title: "Results", description: "Presents the findings of the study." },
          { title: "Conclusion", description: "Summarizes the research and its implications." }
        ],
        keyConcepts: [
          { title: "Demo Concept", description: "This is a placeholder. Real analysis requires an OpenAI API key." }
        ],
        methodology: "Methodology details will be shown when an OpenAI API key is provided.",
        results: "Results will be analyzed when an OpenAI API key is provided."
      };
    }
    
    let prompt: string;

    switch (readingLevel) {
      case "first-read":
        prompt = `
          Analyze this research paper for a first read. Provide:
          1. Key contributions (3-5 bullet points)
          2. Background context (1-2 paragraphs)
          3. Paper structure breakdown by sections
          4. Key concepts explanation
          5. Methodology highlights
          6. Results and impact summary

          Format the response as a JSON object with the following structure:
          {
            "contributions": ["contribution1", "contribution2", ...],
            "background": "Background context...",
            "structure": [
              {"title": "Section title", "description": "Brief description"},
              ...
            ],
            "keyConcepts": [
              {"title": "Concept name", "description": "Brief explanation"},
              ...
            ],
            "methodology": "Methodology highlights...",
            "results": "Results and impact summary..."
          }

          Paper text:
          ${paperText.substring(0, 8000)}
        `;
        break;

      case "second-read":
        prompt = `
          Perform a detailed second-read analysis of this research paper. Focus on:
          1. Deep methodology analysis
          2. Critical examination of arguments
          3. Detailed results interpretation
          4. Relation to other works in the field
          5. Identification of strengths and limitations

          Format the response as a JSON object with the following structure:
          {
            "contributions": ["contribution1", "contribution2", ...],
            "background": "Background context...",
            "structure": [
              {"title": "Section title", "description": "Detailed description"},
              ...
            ],
            "keyConcepts": [
              {"title": "Concept name", "description": "Detailed explanation"},
              ...
            ],
            "methodology": "Detailed methodology analysis...",
            "results": "Comprehensive results interpretation..."
          }

          Paper text:
          ${paperText.substring(0, 10000)}
        `;
        break;

      case "third-read":
        prompt = `
          Conduct a comprehensive line-by-line analysis of this research paper. Provide:
          1. Extremely detailed breakdown of methodology
          2. Mathematical formulation explanation
          3. Algorithm implementation details
          4. Experimental setup dissection
          5. Result interpretation with statistical significance

          Format the response as a JSON object with the following structure:
          {
            "contributions": ["contribution1", "contribution2", ...],
            "background": "Detailed background...",
            "structure": [
              {"title": "Section title", "description": "Line-by-line description"},
              ...
            ],
            "keyConcepts": [
              {"title": "Concept name", "description": "Comprehensive explanation"},
              ...
            ],
            "methodology": "Line-by-line methodology breakdown...",
            "results": "Detailed results analysis..."
          }

          Paper text:
          ${paperText.substring(0, 15000)}
        `;
        break;

      case "quick-summary":
      default:
        prompt = `
          Provide a quick summary of this research paper, highlighting:
          1. Main objective
          2. Key contributions
          3. Core methodology
          4. Primary results
          5. Significance of the work

          Format the response as a JSON object with the following structure:
          {
            "overview": "Brief overall summary of the paper (3-4 paragraphs)...",
            "contributions": ["contribution1", "contribution2", ...],
            "methodology": "Brief methodology summary...",
            "results": "Key results summary..."
          }

          Paper text:
          ${paperText.substring(0, 5000)}
        `;
        break;
    }

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    return JSON.parse(content);
  } catch (error) {
    console.error("Error analyzing paper:", error);
    return {};
  }
}

// Analyze topic relevance
export async function getTopicRelevance(paperText: string, topic: string): Promise<TopicRelevance> {
  try {
    if (!openai) {
      console.warn("OpenAI API not available. Using demo topic relevance.");
      return {
        connections: ["To analyze the actual relevance to your topic, an OpenAI API key is required"],
        nonRelevantAspects: ["Without an API key, I cannot provide specific non-relevant aspects"],
        explanation: `This is a placeholder response. To analyze how "${topic}" relates to this paper, please provide an OpenAI API key.`
      };
    }
    
    const prompt = `
      Analyze the relevance between this research paper and the following topic:
      "${topic}"

      Identify:
      1. Clear connections between the paper and the topic
      2. Aspects of the topic not addressed in the paper
      3. A brief explanation of the relevance

      DO NOT hallucinate connections that do not exist. Be objective and accurate.

      Format the response as a JSON object with the following structure:
      {
        "connections": ["connection1", "connection2", ...],
        "nonRelevantAspects": ["aspect1", "aspect2", ...],
        "explanation": "Brief explanation of relevance..."
      }

      Paper text:
      ${paperText.substring(0, 5000)}
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    return JSON.parse(content);
  } catch (error) {
    console.error("Error analyzing topic relevance:", error);
    return {};
  }
}

// Handle user question
export async function answerQuestion(paperText: string, question: string): Promise<string> {
  try {
    if (!openai) {
      return "I need an OpenAI API key to answer your questions about this paper. Please provide an API key to enable this functionality.";
    }
    
    const prompt = `
      Based on this research paper, answer the following question:
      "${question}"

      Reference specific parts of the paper when appropriate. If you can't answer based on the paper content, acknowledge the limitations.
      DO NOT make up information that isn't supported by the paper.

      Paper text:
      ${paperText.substring(0, 10000)}
    `;

    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }]
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    return content;
  } catch (error) {
    console.error("Error answering question:", error);
    return "I'm sorry, I couldn't process your question. Please try again.";
  }
}
