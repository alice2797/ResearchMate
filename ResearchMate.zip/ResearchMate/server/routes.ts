import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { v4 as uuidv4 } from "uuid";
import { extractTextFromPdf, countPdfPages } from "./pdfParser";
import { extractPaperDetails, analyzePaper, getTopicRelevance, answerQuestion } from "./openai";
import { readingLevels } from "@shared/schema";

// Setup multer for file uploads (store in memory)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Upload a paper
  app.post("/api/papers/upload", upload.single("paper"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, message: "No file uploaded" });
      }

      // Extract text from the PDF
      const fileContent = await extractTextFromPdf(req.file);
      
      // Count pages
      const pageCount = await countPdfPages(req.file.buffer);
      
      // Extract paper details using OpenAI
      const paperDetails = await extractPaperDetails(fileContent);
      
      // Save paper details to storage
      const paper = await storage.createPaper({
        title: paperDetails.title,
        authors: paperDetails.authors,
        publication: paperDetails.publication,
        abstract: paperDetails.abstract,
        pageCount,
        fileName: req.file.originalname,
        fileContent,
        categories: paperDetails.categories || [],
      });

      return res.status(200).json({
        success: true,
        paperId: paper.id,
        paperDetails: {
          title: paper.title,
          authors: paper.authors,
          publication: paper.publication,
          abstract: paper.abstract,
          pageCount: paper.pageCount,
          categories: paper.categories,
        },
      });
    } catch (error) {
      console.error("Error uploading paper:", error);
      return res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Failed to upload paper",
      });
    }
  });

  // Analyze a paper
  app.post("/api/papers/:paperId/analyze", async (req: Request, res: Response) => {
    try {
      const { paperId } = req.params;
      const { readingLevel } = req.body;

      if (!paperId || isNaN(Number(paperId))) {
        return res.status(400).json({ success: false, message: "Invalid paper ID" });
      }

      if (!readingLevel || !readingLevels.includes(readingLevel)) {
        return res.status(400).json({
          success: false,
          message: "Invalid reading level. Must be one of: first-read, second-read, third-read, quick-summary",
        });
      }

      // Get paper from storage
      const paper = await storage.getPaper(Number(paperId));
      if (!paper) {
        return res.status(404).json({ success: false, message: "Paper not found" });
      }

      // Analyze the paper using OpenAI
      const analysis = await analyzePaper(paper.fileContent, readingLevel);

      // Create a session for this analysis
      const session = await storage.createSession({
        paperId: paper.id,
        readingLevel,
        topics: [],
      });

      return res.status(200).json({
        success: true,
        sessionId: session.id,
        analysis,
      });
    } catch (error) {
      console.error("Error analyzing paper:", error);
      return res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Failed to analyze paper",
      });
    }
  });

  // Get topic relevance
  app.post("/api/sessions/:sessionId/topic-relevance", async (req: Request, res: Response) => {
    try {
      const { sessionId } = req.params;
      const { topics } = req.body;

      if (!sessionId || isNaN(Number(sessionId))) {
        return res.status(400).json({ success: false, message: "Invalid session ID" });
      }

      if (!topics || typeof topics !== "string") {
        return res.status(400).json({ success: false, message: "Topics are required" });
      }

      // Get session
      const session = await storage.getSession(Number(sessionId));
      if (!session) {
        return res.status(404).json({ success: false, message: "Session not found" });
      }

      // Get paper from storage
      const paper = await storage.getPaper(session.paperId);
      if (!paper) {
        return res.status(404).json({ success: false, message: "Paper not found" });
      }

      // Update session with topics
      await storage.updateSessionTopics(session.id, [topics]);

      // Analyze topic relevance using OpenAI
      const relevance = await getTopicRelevance(paper.fileContent, topics);

      return res.status(200).json({
        success: true,
        relevance,
      });
    } catch (error) {
      console.error("Error analyzing topic relevance:", error);
      return res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Failed to analyze topic relevance",
      });
    }
  });

  // Send message to session
  app.post("/api/sessions/:sessionId/messages", async (req: Request, res: Response) => {
    try {
      const { sessionId } = req.params;
      const { content } = req.body;

      if (!sessionId || isNaN(Number(sessionId))) {
        return res.status(400).json({ success: false, message: "Invalid session ID" });
      }

      if (!content || typeof content !== "string") {
        return res.status(400).json({ success: false, message: "Message content is required" });
      }

      // Get session
      const session = await storage.getSession(Number(sessionId));
      if (!session) {
        return res.status(404).json({ success: false, message: "Session not found" });
      }

      // Get paper from storage
      const paper = await storage.getPaper(session.paperId);
      if (!paper) {
        return res.status(404).json({ success: false, message: "Paper not found" });
      }

      // Save user message
      await storage.createMessage({
        sessionId: session.id,
        role: "user",
        content,
      });

      // Generate AI response using OpenAI
      const responseContent = await answerQuestion(paper.fileContent, content);

      // Save AI message
      await storage.createMessage({
        sessionId: session.id,
        role: "assistant",
        content: responseContent,
      });

      return res.status(200).json({
        success: true,
        message: {
          id: uuidv4(),
          role: "assistant",
          content: responseContent,
        },
      });
    } catch (error) {
      console.error("Error processing message:", error);
      return res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Failed to process message",
      });
    }
  });

  // Change reading level
  app.post("/api/sessions/:sessionId/reading-level", async (req: Request, res: Response) => {
    try {
      const { sessionId } = req.params;
      const { readingLevel } = req.body;

      if (!sessionId || isNaN(Number(sessionId))) {
        return res.status(400).json({ success: false, message: "Invalid session ID" });
      }

      if (!readingLevel || !readingLevels.includes(readingLevel)) {
        return res.status(400).json({
          success: false,
          message: "Invalid reading level. Must be one of: first-read, second-read, third-read, quick-summary",
        });
      }

      // Get session
      const session = await storage.getSession(Number(sessionId));
      if (!session) {
        return res.status(404).json({ success: false, message: "Session not found" });
      }

      // Get paper from storage
      const paper = await storage.getPaper(session.paperId);
      if (!paper) {
        return res.status(404).json({ success: false, message: "Paper not found" });
      }

      // Update session reading level
      await storage.updateSessionReadingLevel(session.id, readingLevel);

      // Analyze the paper again with the new reading level
      const analysis = await analyzePaper(paper.fileContent, readingLevel);

      return res.status(200).json({
        success: true,
        sessionId: session.id,
        analysis,
      });
    } catch (error) {
      console.error("Error changing reading level:", error);
      return res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : "Failed to change reading level",
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
