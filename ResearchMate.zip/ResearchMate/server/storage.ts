import { 
  users, type User, type InsertUser,
  papers, type Paper, type InsertPaper,
  sessions, type Session, type InsertSession,
  messages, type Message, type InsertMessage,
  ReadingLevel
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Paper operations
  getPaper(id: number): Promise<Paper | undefined>;
  createPaper(paper: InsertPaper): Promise<Paper>;
  
  // Session operations
  getSession(id: number): Promise<Session | undefined>;
  getSessionsByPaperId(paperId: number): Promise<Session[]>;
  createSession(session: InsertSession): Promise<Session>;
  updateSessionTopics(id: number, topics: string[]): Promise<Session>;
  updateSessionReadingLevel(id: number, readingLevel: ReadingLevel): Promise<Session>;
  
  // Message operations
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesBySessionId(sessionId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

// In-memory storage implementation (for reference)
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private papers: Map<number, Paper>;
  private sessions: Map<number, Session>;
  private messages: Map<number, Message>;
  
  private userIdCounter: number;
  private paperIdCounter: number;
  private sessionIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.papers = new Map();
    this.sessions = new Map();
    this.messages = new Map();
    
    this.userIdCounter = 1;
    this.paperIdCounter = 1;
    this.sessionIdCounter = 1;
    this.messageIdCounter = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Paper operations
  async getPaper(id: number): Promise<Paper | undefined> {
    return this.papers.get(id);
  }

  async createPaper(insertPaper: InsertPaper): Promise<Paper> {
    const id = this.paperIdCounter++;
    const now = new Date();
    const paper: Paper = { 
      ...insertPaper, 
      id, 
      uploadedAt: now,
    };
    this.papers.set(id, paper);
    return paper;
  }
  
  // Session operations
  async getSession(id: number): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async getSessionsByPaperId(paperId: number): Promise<Session[]> {
    return Array.from(this.sessions.values()).filter(
      (session) => session.paperId === paperId
    );
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = this.sessionIdCounter++;
    const now = new Date();
    const session: Session = {
      ...insertSession,
      id,
      createdAt: now,
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSessionTopics(id: number, topics: string[]): Promise<Session> {
    const session = this.sessions.get(id);
    if (!session) {
      throw new Error(`Session with ID ${id} not found`);
    }
    
    const updatedSession: Session = {
      ...session,
      topics,
    };
    
    this.sessions.set(id, updatedSession);
    return updatedSession;
  }

  async updateSessionReadingLevel(id: number, readingLevel: ReadingLevel): Promise<Session> {
    const session = this.sessions.get(id);
    if (!session) {
      throw new Error(`Session with ID ${id} not found`);
    }
    
    const updatedSession: Session = {
      ...session,
      readingLevel,
    };
    
    this.sessions.set(id, updatedSession);
    return updatedSession;
  }
  
  // Message operations
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessagesBySessionId(sessionId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.sessionId === sessionId
    );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: now,
    };
    this.messages.set(id, message);
    return message;
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async getPaper(id: number): Promise<Paper | undefined> {
    const [paper] = await db.select().from(papers).where(eq(papers.id, id));
    return paper || undefined;
  }

  async createPaper(insertPaper: InsertPaper): Promise<Paper> {
    const [paper] = await db
      .insert(papers)
      .values(insertPaper)
      .returning();
    return paper;
  }
  
  async getSession(id: number): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session || undefined;
  }

  async getSessionsByPaperId(paperId: number): Promise<Session[]> {
    return await db.select().from(sessions).where(eq(sessions.paperId, paperId));
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db
      .insert(sessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async updateSessionTopics(id: number, topics: string[]): Promise<Session> {
    const [updatedSession] = await db
      .update(sessions)
      .set({ topics })
      .where(eq(sessions.id, id))
      .returning();
    
    if (!updatedSession) {
      throw new Error(`Session with ID ${id} not found`);
    }
    
    return updatedSession;
  }

  async updateSessionReadingLevel(id: number, readingLevel: ReadingLevel): Promise<Session> {
    const [updatedSession] = await db
      .update(sessions)
      .set({ readingLevel })
      .where(eq(sessions.id, id))
      .returning();
    
    if (!updatedSession) {
      throw new Error(`Session with ID ${id} not found`);
    }
    
    return updatedSession;
  }
  
  async getMessage(id: number): Promise<Message | undefined> {
    const [message] = await db.select().from(messages).where(eq(messages.id, id));
    return message || undefined;
  }

  async getMessagesBySessionId(sessionId: number): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.sessionId, sessionId));
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }
}

// Export an instance of DatabaseStorage for use throughout the application
export const storage = new DatabaseStorage();
