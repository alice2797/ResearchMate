import { drizzle } from 'drizzle-orm/neon-serverless';
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is required');
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

async function main() {
  console.log('Pushing schema to database...');
  
  try {
    // Custom push mechanism since we're not using migrations
    console.log('Creating users table...');
    await db.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      )
    `);
    
    console.log('Creating papers table...');
    await db.execute(`
      CREATE TABLE IF NOT EXISTS papers (
        id SERIAL PRIMARY KEY,
        title TEXT,
        authors TEXT,
        publication TEXT,
        abstract TEXT,
        page_count INTEGER,
        file_name TEXT NOT NULL,
        file_content TEXT NOT NULL,
        uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
        categories TEXT[]
      )
    `);
    
    console.log('Creating sessions table...');
    await db.execute(`
      CREATE TABLE IF NOT EXISTS sessions (
        id SERIAL PRIMARY KEY,
        paper_id INTEGER NOT NULL,
        reading_level TEXT NOT NULL,
        topics TEXT[],
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
      )
    `);
    
    console.log('Creating messages table...');
    await db.execute(`
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        session_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
      )
    `);
    
    console.log('Schema pushed successfully.');
  } catch (error) {
    console.error('Error pushing schema:', error);
    process.exit(1);
  }
  
  await pool.end();
}

main();