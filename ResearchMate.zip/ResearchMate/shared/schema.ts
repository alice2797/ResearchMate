import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const papers = pgTable("papers", {
  id: serial("id").primaryKey(),
  title: text("title"),
  authors: text("authors"),
  publication: text("publication"),
  abstract: text("abstract"),
  pageCount: integer("page_count"),
  fileName: text("file_name").notNull(),
  fileContent: text("file_content").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
  categories: text("categories").array(),
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  paperId: integer("paper_id").notNull(),
  readingLevel: text("reading_level").notNull(),
  topics: text("topics").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPaperSchema = createInsertSchema(papers).pick({
  title: true,
  authors: true,
  publication: true,
  abstract: true,
  pageCount: true,
  fileName: true,
  fileContent: true,
  categories: true,
});

export const insertSessionSchema = createInsertSchema(sessions).pick({
  paperId: true,
  readingLevel: true,
  topics: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  sessionId: true,
  role: true,
  content: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Paper = typeof papers.$inferSelect;
export type InsertPaper = z.infer<typeof insertPaperSchema>;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

// Paper Analysis Types for OpenAI responses
export const readingLevels = ['first-read', 'second-read', 'third-read', 'quick-summary'] as const;
export type ReadingLevel = typeof readingLevels[number];

export const paperDetailsSchema = z.object({
  title: z.string().optional(),
  authors: z.string().optional(),
  publication: z.string().optional(),
  abstract: z.string().optional(),
  pageCount: z.number().optional(),
  categories: z.array(z.string()).optional(),
});

export type PaperDetails = z.infer<typeof paperDetailsSchema>;

export const paperAnalysisSchema = z.object({
  overview: z.string().optional(),
  contributions: z.array(z.string()).optional(),
  background: z.string().optional(),
  structure: z.array(z.object({
    title: z.string(),
    description: z.string()
  })).optional(),
  keyConcepts: z.array(z.object({
    title: z.string(),
    description: z.string()
  })).optional(),
  methodology: z.string().optional(),
  results: z.string().optional(),
});

// Define and export PaperAnalysis type
export type PaperAnalysis = {
  overview?: string;
  contributions?: string[];
  background?: string;
  structure?: Array<{
    title: string;
    description: string;
  }>;
  keyConcepts?: Array<{
    title: string;
    description: string;
  }>;
  methodology?: string;
  results?: string;
};

export const topicRelevanceSchema = z.object({
  connections: z.array(z.string()).optional(),
  nonRelevantAspects: z.array(z.string()).optional(),
  explanation: z.string().optional(),
});

// Define and export TopicRelevance type
export type TopicRelevance = {
  connections?: string[];
  nonRelevantAspects?: string[];
  explanation?: string;
};
